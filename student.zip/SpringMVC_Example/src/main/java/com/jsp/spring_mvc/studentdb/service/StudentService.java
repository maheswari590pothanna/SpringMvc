package com.jsp.spring_mvc.studentdb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.jsp.spring_mvc.studentdb.entity.Student;
import com.jsp.spring_mvc.studentdb.repository.StudentRepository;

@Service
public class StudentService {
	
	@Autowired
	private StudentRepository studentRepository;
	
	public ModelAndView addStudent(Student student) {
		studentRepository.addStudent(student);
		
//		ModelAndView mav = new ModelAndView();
//		mav.setViewName("index.jsp");
		
		return new ModelAndView("index.jsp");
	}
	
	public ModelAndView displayAllStudents() {
		//Fetching all the students details from the database
		
		List<Student> students = studentRepository.findAllStudents();
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("DisplayAllStudents.jsp");
		mav.addObject("studentList", students);
		
		return mav;
	}
	
	public ModelAndView findStudentById(int studentId) {
		//Fetching the student object based on Id
		
		Student student = studentRepository.findStudentById(studentId);
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("UpdateStudent.jsp");
		mav.addObject("studentObject", student);
		
		return mav;
	}
	
	public ModelAndView updateStudent(Student student) {
		//Update student record in the database
		
		studentRepository.updateStudent(student);
		
//		ModelAndView mav = new ModelAndView();
//		mav.setViewName("redirect:display-all-students");
		
		return new ModelAndView("redirect:display-all-students");
	}

	public ModelAndView deleteStudent(int studentId) {
		//Deleting the student record from the database
		
		studentRepository.deleteStudentById(studentId);
		
//		ModelAndView mav = new ModelAndView();
//		mav.setViewName("redirect:display-all-students");
		
		return new ModelAndView("redirect:display-all-students");
	}
}
