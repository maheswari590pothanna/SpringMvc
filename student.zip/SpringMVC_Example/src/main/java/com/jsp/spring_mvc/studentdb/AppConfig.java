package com.jsp.spring_mvc.studentdb;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.jsp.spring_mvc.studentdb")
public class AppConfig {

}
